Please see ..\java.desktop\mesa3d.md
